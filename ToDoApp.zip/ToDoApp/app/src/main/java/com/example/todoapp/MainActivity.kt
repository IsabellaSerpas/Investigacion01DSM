package com.example.todoapp

import android.content.Context
import android.graphics.Paint
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextTask: EditText
    private lateinit var buttonAddTask: Button
    private lateinit var buttonDeleteTask: Button
    private lateinit var listViewTasks: ListView
    private lateinit var adapter: ArrayAdapter<String>

    private val tasks = mutableListOf<Task>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias a los elementos de la interfaz
        editTextTask = findViewById(R.id.editTextTask)
        buttonAddTask = findViewById(R.id.buttonAddTask)
        buttonDeleteTask = findViewById(R.id.buttonDeleteTask)
        listViewTasks = findViewById(R.id.listViewTasks)

        // Cargar tareas desde SharedPreferences
        loadTasks()

        // Configurar adaptador personalizado para mostrar las tareas
        adapter = object : ArrayAdapter<String>(
            this,
            android.R.layout.simple_list_item_multiple_choice,
            tasks.map { it.description }
        ) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val view = super.getView(position, convertView, parent) as CheckedTextView
                view.isChecked = tasks[position].isDone
                view.paintFlags = if (tasks[position].isDone) {
                    view.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                } else {
                    view.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                }
                return view
            }
        }

        listViewTasks.adapter = adapter
        listViewTasks.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        // Agregar nueva tarea
        buttonAddTask.setOnClickListener {
            val text = editTextTask.text.toString()
            if (text.isNotBlank()) {
                val newTask = Task(text)
                tasks.add(newTask)
                editTextTask.text.clear()
                refreshList()
                saveTasks()
            } else {
                Toast.makeText(this, "La tarea no puede estar vacía", Toast.LENGTH_SHORT).show()
            }
        }

        // Marcar/desmarcar tarea como completada
        listViewTasks.setOnItemClickListener { _, _, position, _ ->
            tasks[position].isDone = !tasks[position].isDone
            refreshList()
            saveTasks()
        }

        // Eliminar tareas seleccionadas al presionar el botón
        buttonDeleteTask.setOnClickListener {
            val toRemove = tasks.filterIndexed { index, _ -> listViewTasks.isItemChecked(index) }
            if (toRemove.isNotEmpty()) {
                tasks.removeAll(toRemove)
                refreshList()
                saveTasks()
                Toast.makeText(this, "Tarea(s) eliminada(s)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Selecciona al menos una tarea", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun refreshList() {
        adapter.clear()
        adapter.addAll(tasks.map { it.description })
        adapter.notifyDataSetChanged()

        // Esperar a que se complete el render y luego actualizar los checkboxes
        listViewTasks.post {
            for (i in tasks.indices) {
                listViewTasks.setItemChecked(i, tasks[i].isDone)
            }
        }
    }

    // Guardar tareas en SharedPreferences
    private fun saveTasks() {
        val prefs = getSharedPreferences("todo_prefs", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        val stringSet = tasks.map { it.toStorageString() }.toSet()
        editor.putStringSet("task_list", stringSet)
        editor.apply()
    }

    // Cargar tareas desde SharedPreferences
    private fun loadTasks() {
        val prefs = getSharedPreferences("todo_prefs", Context.MODE_PRIVATE)
        val stringSet = prefs.getStringSet("task_list", emptySet())
        tasks.clear()
        stringSet?.forEach { str ->
            Task.fromStorageString(str)?.let { tasks.add(it) }
        }
    }
}
