package com.example.todoapp

data class Task(
    var description: String,
    var isDone: Boolean = false
) {
    fun toStorageString(): String {
        return "$description|$isDone"
    }

    companion object {
        fun fromStorageString(data: String): Task? {
            val parts = data.split("|")
            return if (parts.size == 2) {
                Task(parts[0], parts[1].toBoolean())
            } else {
                null
            }
        }
    }
}
